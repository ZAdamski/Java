import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class ClientHandler extends Thread {
    private final Socket socket;
    private PrintWriter streamWriter;
    private BufferedReader streamReader;
    private final JFrame f = new JFrame();

    public ClientHandler(Socket socket) {
        this.socket = socket;
        try {
            streamWriter = new PrintWriter(socket.getOutputStream(), true);
            streamReader = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(f, "IO error");
        }
        System.out.println("Created Client Handler");
    }

    @Override
    public void run() {
        try {
            label:
            while (true) {
                String in = streamReader.readLine();
                switch (in) {
                    case "EXIT":
                    case "exit":
                        break label;
                    case "updateoffer": {
                        ArrayList<String> temp = new ArrayList<>();
                        temp.add("1");
                        temp.add("2");
                        temp.add("3");
                        temp.set(0, streamReader.readLine());
                        temp.set(1, streamReader.readLine());
                        temp.set(2, streamReader.readLine());
                        CentralGUI.addAttraction(temp);
                        break;
                    }
                    case "getattractions": {
                        ArrayList<ArrayList<String>> temp = CentralGUI.getAttractions();
                        for (ArrayList<String> strings : temp) {
                            streamWriter.println("more");
                            streamWriter.println(strings.get(0));
                            streamWriter.println(strings.get(1));
                            streamWriter.println(strings.get(2));
                        }
                        break;
                    }
                    case "buy": {
                        int index = Integer.parseInt(streamReader.readLine());
                        String response = CentralGUI.getAttractionAtIndex(index);
                        streamWriter.println(response);
                        break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                System.out.println("Closed Client Connection");
                streamReader.close();
                streamWriter.close();
                socket.close();
                this.stop();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
