import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLOutput;
import java.util.ArrayList;

public class AdminGUI extends JFrame {
    private final Dimension SCREEN = Toolkit.getDefaultToolkit().getScreenSize();
    private final String TITLE = "Admin terminal";

    private final int SCREEN_WIDTH = SCREEN.width;
    private final int SCREEN_HEIGHT = SCREEN.height;
    private final int WINDOW_WIDTH = 800;
    private final int WINDOW_HEIGHT = 600;

    private JPanel mainPanel;
    private JButton pushAttractions;
    private JTextField attractionSeats;
    private JTextField attractionName;
    private JTextField attractionPrice;
    private JButton addAttraction;
    private JTable attractionList;
    private JLabel nameLabel;
    private JLabel seatsLabel;
    private JLabel priceLabel;
    private Client client;
    Thread clientThread;

    private static final ArrayList<ArrayList<String>> attractions = new ArrayList<>();

    String[][] data;
    String[] header = {"NAME", "SEATS LEFT", "PRICE"};

    public AdminGUI(){
        attractionList.setModel(new DefaultTableModel(
                data,
                header
        ));
        DefaultTableModel tableModel = (DefaultTableModel) attractionList.getModel();
        TableColumnModel tcm = attractionList.getColumnModel();
        attractionList.getTableHeader().setReorderingAllowed(false);

        setTitle(TITLE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(mainPanel);
        setBounds((SCREEN_WIDTH - WINDOW_WIDTH)/2, (SCREEN_HEIGHT - WINDOW_HEIGHT)/2 , WINDOW_WIDTH, WINDOW_HEIGHT);
        setVisible(true);

        client = new Client();
        clientThread = new Thread(client);
        clientThread.start();

        addAttraction.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] data = {
                        attractionName.getText(),
                        attractionSeats.getText(),
                        attractionPrice.getText(),
                };
                tableModel.addRow(data);

                ArrayList<String> temp = new ArrayList<>();
                temp.add(attractionName.getText());
                temp.add(attractionSeats.getText());
                temp.add(attractionPrice.getText());
                attractions.add(temp);
            }
        });

        pushAttractions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < attractions.size(); i++){
                    client.sendMessage("updateoffer");
                    client.sendMessage(attractions.get(i).get(0));
                    client.sendMessage(attractions.get(i).get(1));
                    client.sendMessage(attractions.get(i).get(2));
                }
                attractions.removeAll(attractions);
                tableModel.setRowCount(0);
            }
        });
    }

    @Override
    public void dispose() {
        attractions.removeAll(attractions);
        client.exit();
        clientThread.stop();
        super.dispose();
    }
}
