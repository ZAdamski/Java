import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CentralGUI extends JFrame {
    private final Dimension SCREEN = Toolkit.getDefaultToolkit().getScreenSize();
    private final String TITLE = "Central terminal";

    private final int SCREEN_WIDTH = SCREEN.width;
    private final int SCREEN_HEIGHT = SCREEN.height;
    private final int WINDOW_WIDTH = 800;
    private final int WINDOW_HEIGHT = 600;

    private JPanel mainPanel;
    private JButton addClient;
    private JButton startServer;
    private JButton addAdmin;
    private JLabel label;
    private JTable attractionTable;
    private static DefaultTableModel tableModel;

    private static final ArrayList<ArrayList<String>> attractionList = new ArrayList<>();

    String[][] data;
    String[] header = {"NAME", "SEATS", "PRICE"};

    private CentralGUI(){
        attractionTable.setModel(new DefaultTableModel(
                data,
                header
        ));
        tableModel = (DefaultTableModel) attractionTable.getModel();
        TableColumnModel tcm = attractionTable.getColumnModel();
        attractionTable.getTableHeader().setReorderingAllowed(false);

        setTitle(TITLE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(mainPanel);
        setBounds((SCREEN_WIDTH - WINDOW_WIDTH)/2, (SCREEN_HEIGHT - WINDOW_HEIGHT)/2 , WINDOW_WIDTH, WINDOW_HEIGHT);
        setVisible(true);


        addClient.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TicketGUI ticket = new TicketGUI();
            }
        });

        startServer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Server server = new Server();
                Thread serverThread = new Thread(server);
                serverThread.start();
            }
        });

        addAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AdminGUI admin = new AdminGUI();
            }
        });
    }

    public static synchronized void addAttraction(ArrayList<String> attraction){
        String[] data = {
                attraction.get(0),
                attraction.get(1),
                attraction.get(2),
        };
        tableModel.addRow(data);

        ArrayList<String> temp = new ArrayList<>();
        temp.add(attraction.get(0));
        temp.add(attraction.get(1));
        temp.add(attraction.get(2));
        attractionList.add(temp);
    }

    public static synchronized ArrayList<ArrayList<String>> getAttractions(){
        return attractionList;
    }

    public static void main(String[] args) {
        CentralGUI cgui = new CentralGUI();
    }

    public static String getAttractionAtIndex(int index) {
        if (Integer.parseInt(attractionList.get(index).get(1)) <= 0){
            return "bad";
        } else {
            attractionList.get(index).set(1, String.valueOf(Integer.parseInt(attractionList.get(index).get(1)) - 1));
            tableModel.setValueAt(attractionList.get(index).get(1), index, 1);
            return "good";
        }
    }
}
