import javax.swing.*;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Server implements Runnable {
    private static final JFrame f = new JFrame();
    private static final int PORT_NUM = 6666;

    @Override
    public void run() {
        Socket socket;
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(PORT_NUM);
            System.out.println("Created Server");
        }
        catch (IOException e){
            e.printStackTrace();
        }

        while (true){
            try{
                socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(socket);
                clientHandler.start();
            }
            catch (Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(f,"Connection error");
            }
        }
    }

}
