import javax.swing.*;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class Client implements Runnable {
    private InetAddress address = null;
    private Socket socket;
    private PrintWriter streamWriter = null;
    private BufferedReader streamReader = null;

    @Override
    public void run (){
        try {
            address = InetAddress.getLocalHost();
        }
        catch (UnknownHostException e){
            e.printStackTrace();
        }

        try {
            socket = new Socket(address, 6666);
            streamWriter = new PrintWriter(socket.getOutputStream(), true);
            streamReader = new BufferedReader(
                                    new InputStreamReader(
                                            socket.getInputStream()));

            System.out.println("Created Client");

        }
        catch (IOException e){
            e.printStackTrace();
        }
        JFrame f = new JFrame();
        try {
            while (true) {
                if (streamReader.readLine().equals("more")){
                        String[] data = {
                                streamReader.readLine(),
                                streamReader.readLine(),
                                streamReader.readLine()
                        };
                        TicketGUI.addAttraction(data);
                }
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }



    protected void exit(){
        streamWriter.println("exit");
    }

    protected void sendMessage(String message){
        streamWriter.println(message);
    }

}
