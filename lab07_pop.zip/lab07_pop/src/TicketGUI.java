import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.io.IOException;

public class TicketGUI extends JFrame {
    private final Dimension SCREEN = Toolkit.getDefaultToolkit().getScreenSize();
    private final String TITLE = "Ticket terminal";

    private final int SCREEN_WIDTH = SCREEN.width;
    private final int SCREEN_HEIGHT = SCREEN.height;
    private final int WINDOW_WIDTH = 800;
    private final int WINDOW_HEIGHT = 600;

    private JPanel mainPanel;
    private JButton buyTicketButton;
    private JTable attractionTable;
    private JButton getAttractions;
    private Client client;
    private static Thread clientThread;
    private static DefaultTableModel tableModel;
    String[][] data;
    String[] header = {"NAME", "SEATS LEFT", "PRICE"};

    public TicketGUI(){
        attractionTable.setModel(new DefaultTableModel(
                data,
                header
        ));
        tableModel = (DefaultTableModel) attractionTable.getModel();
        TableColumnModel tcm = attractionTable.getColumnModel();
        attractionTable.getTableHeader().setReorderingAllowed(false);

        setTitle(TITLE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(mainPanel);
        setBounds((SCREEN_WIDTH - WINDOW_WIDTH)/2, (SCREEN_HEIGHT - WINDOW_HEIGHT)/2 , WINDOW_WIDTH, WINDOW_HEIGHT);
        setVisible(true);

        client = new Client();
        clientThread = new Thread(client);
        clientThread.start();

        getAttractions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);
                client.sendMessage("getattractions");
            }
        });

        buyTicketButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                client.sendMessage("buy");
                if (attractionTable.getSelectedRow() < 0){
                    JOptionPane.showMessageDialog(TicketGUI.this, "Select an attraction");
                }
                client.sendMessage(String.valueOf(attractionTable.getSelectedRow()));

            }
        });
    }

    public static synchronized void addAttraction(String[] data) {
        tableModel.addRow(data);
    }


    @Override
    public void dispose() {
        client.exit();
        clientThread.stop();
        super.dispose();
    }
}
