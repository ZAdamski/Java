Aby uruchomić aplikację:

java -jar lab-03_pop.jar

aby zmienić klasę z jakiej uruchamiamy program (a za razem funkcjonalność aplikacji) 
należy zmienić Main-Class w pliku MANIFEST w samym jarze. 
Lista dostępnych klas (typów użytkowników)
AuthorUI
EditorUI
ReviewerUI