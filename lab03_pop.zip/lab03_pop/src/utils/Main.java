package utils;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import model.Record;

//Main sluzyl mi do debugowania i sprawdzania dzialania funkcji
//oraz dostarcza jedna instancje klasy Scanner do calego programu
//i metode clearScreen czyszczaca ekran konsoli

public class Main {
	public static Scanner scan = new Scanner(System.in);
	private static File RecordsPending = new File("RecordsPending.xml");
	private static File RecordsAccepted = new File("RecordsAccepted.xml");

	public static void main(String[] args) {
		// clearConsole();
		// CsvUtil.readFile(RecordsPending, Record.recordsPending);
		// CsvUtil.readFile(RecordsAccepted, Record.recordsAccepted);
		// CsvUtil.viewRecordsPending();
		// CsvUtil.viewRecordsAccepted();

		// CsvUtil.saveToFile(RecordsPending, Record.recordsPending);
		// CsvUtil.saveToFile(RecordsAccepted, Record.recordsAccepted);
	}

	public static void clearConsole() {
		try {
			if (System.getProperty("os.name").contains("Windows")) { // try for Windows
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			} else { // try for Linux
				Runtime.getRuntime().exec("clear");
			}
		} catch (IOException | InterruptedException ex) {
		}
	}
}
