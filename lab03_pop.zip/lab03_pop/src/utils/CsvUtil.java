package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;

import model.Record;

public class CsvUtil {

	public static void viewRecordsPending() {
		Main.clearConsole();
		System.out.println("\nPENDING RECORDS");
		for (int i = 0; i < Record.recordsPending.size(); i++) {
			System.out.println(String.valueOf(i + 1) + ". " + Record.recordsPending.get(i));
		}
	}

	public static void viewRecordsAccepted() {
		Main.clearConsole();
		System.out.println("\nACCEPTED RECORDS");
		for (int i = 0; i < Record.recordsAccepted.size(); i++) {
			System.out.println(String.valueOf(i + 1) + ". " + Record.recordsAccepted.get(i));
		}
	}

	public static void readFile(File f, ArrayList<Record> arr) {
		try {
			Scanner scan = new Scanner(f);
			while (scan.hasNext()) {
				String s = scan.nextLine();
				String[] split = s.split(";");

				String name = split[0];
				String definition = split[1];
				String status = split[2];
				String author = split[3];
				String comment = split[4];

				new Record(name, definition, status, author, comment, arr);
			}

			scan.close();
		} catch (FileNotFoundException e) {
			System.out.println("Blad w odczytywaniu pliku: " + e.getMessage());
		}
	}

	public static void saveToFile(File f, ArrayList<Record> arr) {
		File copy = new File(f.getName() + ".bak");

		if (f.exists()) {
			try {
				Files.copy(f.toPath(), copy.toPath());
			} catch (IOException e) {
				System.out.println("Blad przy tworzeniu kopii: " + e.getMessage());
			}
		}

		try {

			FileWriter save = new FileWriter(f);
			for (Record t : arr) {
				save.write(t.strToSave() + "\n");
			}
			save.close();
			copy.delete();

		} catch (FileNotFoundException e) {
			System.out.println("Nie udalo sie zapisac: " + e.getMessage());
			try {
				Files.copy(copy.toPath(), f.toPath());
			} catch (IOException e1) {
				System.out.println("Blad przy przywracaniu kopii: " + e1.getMessage());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
