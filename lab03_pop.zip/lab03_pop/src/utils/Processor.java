package utils;

import model.Record;
import static utils.Main.scan;

public class Processor {

	public static void authorViewOwnRecordsPending(String authorId) {
		System.out.println("\nPENDING RECORDS");
		for (int i = 0; i < Record.recordsPending.size(); i++) {
			if (Record.recordsPending.get(i).author.equals(authorId)) {
				System.out.println(String.valueOf(i + 1) + ". " + Record.recordsPending.get(i).name + ": "
						+ Record.recordsPending.get(i).status);
			}
		}
	}

	public static void authorAddRecord(String author) {
		System.out.println("What's the title?\n");
		scan.nextLine();
		String n = scan.nextLine();
		System.out.println("What's the definition\n");
		String d = scan.nextLine();
		String s = "SUBMITTED";
		String a = author;
		new Record(n, d, s, a, Record.recordsPending);
	}

	public static void authorEditRecord(Record r) {
		System.out.println(r);
		System.out.println("Edit the title");
		scan.nextLine();
		r.name = scan.nextLine();
		System.out.println("Edit the definition");
		r.definition = scan.nextLine();
		r.status = "EDITED";
		r.comment = " ";
	}

	public static void editorViewSubmittedAndReviewedRecords() {
		System.out.println("\nPENDING RECORDS\n");
		for (int i = 0; i < Record.recordsPending.size(); i++) {
			if (Record.recordsPending.get(i).status.equals("SUBMITTED")
					|| Record.recordsPending.get(i).status.equals("EDITED")
					|| Record.recordsPending.get(i).status.equals("REVIEWED")
					|| Record.recordsPending.get(i).status.equals("READY")) {
				System.out.println(String.valueOf(i + 1) + ". " + Record.recordsPending.get(i));
			}
		}
	}

	public static void editorChoice(Record r) {
		System.out.println(r);
		System.out.println("What is your decision?\n"
				+ "1. Send to reviewer\n" 
				+ "2. Send to author for editing\n"
				+ "3. Accept the record\n"
				+ "4. Remove the submission");
		int decision = scan.nextInt();
		switch (decision) {
		case 1:
			r.status = "FOR REVIEW";
			break;
		case 2:
			break;
		case 3:
			new Record(r.name, r.definition, "ACCEPTED", r.author, "ACCEPTED", Record.recordsAccepted);
			Record.recordsPending.remove(getIndex(r));
			break;
		case 4: 
			Record.recordsPending.remove(getIndex(r));
			break;
		default: 
			break;
		}
	}

	public static void reviewerShowForReviewRecords() {
		System.out.println("\nRECORDS FOR REVIEW\n");
		for (int i = 0; i < Record.recordsPending.size(); i++) {
			if (Record.recordsPending.get(i).status.equals("FOR REVIEW")) {
				System.out.println(String.valueOf(i + 1) + ". " + Record.recordsPending.get(i));
			}
		}
	}

	public static void reviewerReviewRecord(Record r) {
		System.out.println(r);
		System.out.println(
				"\nWhat is your decision after reviewing this record?\n"
						+ "1. Accept the record and send to editor\n"
						+ "2. Dont accept and send to author for further corrections\n");
		int decision = scan.nextInt();
		switch (decision) {
		case 1:
			r.comment = "READY FOR SUBMISSION";
			r.status = "READY";
			break;
		case 2:
			reviewerAddComment(r);
		}
	}

	public static void reviewerAddComment(Record r) {
		System.out.println(r);
		System.out.println("Add your comment");
		r.status = "REVIEWED";
		scan.nextLine();
		r.comment = scan.nextLine();
	}

	public static int getIndex(Record r) {
		int x = 0;
		for (int i = 0; i < Record.recordsPending.size(); i++) {
			if (r.name.equals(Record.recordsPending.get(i).name)
					&& r.definition.equals(Record.recordsPending.get(i).definition)) {
				x = i;
			}
		}
		return x;
	}
}
