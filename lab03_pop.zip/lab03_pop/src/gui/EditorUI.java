package gui;

import java.io.File;
import model.Record;
import utils.CsvUtil;
import utils.Main;
import utils.Processor;
import static utils.Main.scan;

public class EditorUI {

	private static File RecordsPending = new File("RecordsPending.xml");
	private static File RecordsAccepted = new File("RecordsAccepted.xml");

	public static void main(String[] args) {
		CsvUtil.readFile(RecordsPending, Record.recordsPending);
		CsvUtil.readFile(RecordsAccepted, Record.recordsAccepted);

		editorMenu();

		CsvUtil.saveToFile(RecordsPending, Record.recordsPending);
		CsvUtil.saveToFile(RecordsAccepted, Record.recordsAccepted);
	}

	static void editorMenu() {
		while (true) {
			Main.clearConsole();
			System.out.println("1. View pending records\n" + "2. View accepted records\n"
					+ "3. Show records waiting for editor's decision\n" + "\n\n9. Exit");
			int decision1 = scan.nextInt();
			int decision2;
			switch (decision1) {
			case 1:
				Main.clearConsole();
				CsvUtil.viewRecordsPending();
				System.out.println("\n9. Back");
				decision2 = scan.nextInt();
				if (decision2 == 9)
					editorMenu();
				break;
			case 2:
				Main.clearConsole();
				CsvUtil.viewRecordsAccepted();
				System.out.println("\n9. Back");
				decision2 = scan.nextInt();
				if (decision2 == 9)
					editorMenu();
				break;
			case 3:
				Main.clearConsole();
				Processor.editorViewSubmittedAndReviewedRecords();
				editorChoiceMenu();
				break;
			case 9:
				return;
			default:
				editorMenu();
			}
		}
	}

	static void editorChoiceMenu() {
		System.out.println("\n\nWhich record would you like to work on?\n\n0.Back");
		int decision = scan.nextInt();
		if (decision == 0)
			return;
		Processor.editorChoice(Record.recordsPending.get(decision - 1));
	}
}
