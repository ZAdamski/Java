package gui;

import java.io.File;
import model.Record;
import utils.CsvUtil;
import utils.Main;
import utils.Processor;
import static utils.Main.scan;

public class AuthorUI {
	public static String authorId;

	private static File RecordsPending = new File("RecordsPending.xml");
	private static File RecordsAccepted = new File("RecordsAccepted.xml");

	public static void main(String[] args) {
		CsvUtil.readFile(RecordsPending, Record.recordsPending);
		CsvUtil.readFile(RecordsAccepted, Record.recordsAccepted);
		Main.clearConsole();

		System.out.println("What is your name?\n");
		authorId = scan.nextLine();

		authorMenu();

		CsvUtil.saveToFile(RecordsPending, Record.recordsPending);
		CsvUtil.saveToFile(RecordsAccepted, Record.recordsAccepted);
	}

	static void authorMenu() {
		while (true) {
			Main.clearConsole();
			System.out.println("1. View own submissions' status\n" + "2. Submit a record\n"
					+ "3. Edit reviewed records\n" + "\n\n9. Exit");
			int decision1 = scan.nextInt();
			int decision2;
			switch (decision1) {
			case 1:
				Main.clearConsole();
				Processor.authorViewOwnRecordsPending(authorId);
				System.out.println("\n9. Back");
				decision2 = scan.nextInt();
				if (decision2 == 9)
					authorMenu();
				break;
			case 2:
				Main.clearConsole();
				Processor.authorAddRecord(authorId);
				break;
			case 3:
				Main.clearConsole();
				authorChoiceMenu();
				break;
			case 9:
				return;
			default:
				authorMenu();
			}
		}
	}

	static void authorChoiceMenu() {
		Processor.authorViewOwnRecordsPending(authorId);
		System.out.println("\n\nWhich record would you like to edit?\n\n0.Back");
		int decision = scan.nextInt();
		if (decision == 0)
			return;
		Processor.authorEditRecord(Record.recordsPending.get(decision - 1));
	}
}
