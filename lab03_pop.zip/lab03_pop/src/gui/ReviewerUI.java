package gui;

import java.io.File;
import model.Record;
import utils.CsvUtil;
import utils.Main;
import utils.Processor;
import static utils.Main.scan;

public class ReviewerUI {

	private static File RecordsPending = new File("RecordsPending.xml");
	private static File RecordsAccepted = new File("RecordsAccepted.xml");

	public static void main(String[] args) {
		CsvUtil.readFile(RecordsPending, Record.recordsPending);
		CsvUtil.readFile(RecordsAccepted, Record.recordsAccepted);

		reviewerMenu();

		CsvUtil.saveToFile(RecordsPending, Record.recordsPending);
		CsvUtil.saveToFile(RecordsAccepted, Record.recordsAccepted);
	}

	static void reviewerMenu() {
		while (true) {
			Main.clearConsole();
			System.out.println("1. View pending records\n" + "2. View accepted records\n"
					+ "3. Show and review submissions\n" + "\n\n9. Exit");
			int decision1 = scan.nextInt();
			int decision2;
			switch (decision1) {
			case 1:
				Main.clearConsole();
				CsvUtil.viewRecordsPending();
				System.out.println("\n9. Back");
				decision2 = scan.nextInt();
				if (decision2 == 9)
					reviewerMenu();
				break;
			case 2:
				Main.clearConsole();
				CsvUtil.viewRecordsAccepted();
				System.out.println("\n9. Back");
				decision2 = scan.nextInt();
				if (decision2 == 9)
					reviewerMenu();
				break;
			case 3:
				Main.clearConsole();
				Processor.reviewerShowForReviewRecords();
				reviewChoiceMenu();
				break;
			case 9:
				return;
			default:
				reviewerMenu();
			}
		}
	}

	static void reviewChoiceMenu() {
		System.out.println("\n\nWhich record would you like to review?\n\n0.Back");
		int decision = scan.nextInt();
		Processor.reviewerReviewRecord(Record.recordsPending.get(decision - 1));
	}
}
