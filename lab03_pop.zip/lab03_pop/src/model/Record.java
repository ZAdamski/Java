package model;

import java.util.ArrayList;

public class Record {

	public static ArrayList<Record> recordsPending = new ArrayList<>();
	public static ArrayList<Record> recordsAccepted = new ArrayList<>();

	public String name;
	public String definition;
	public String status;
	public String author;
	public String comment = " ";

	public Record(String name, String definition, String status, String author, ArrayList<Record> arr) {
		this.name = name;
		this.definition = definition;
		this.status = status;
		this.author = author;

		arr.add(this);
	}

	public Record(String name, String definition, String status, String author, String comment, ArrayList<Record> arr) {
		this.name = name;
		this.definition = definition;
		this.status = status;
		this.author = author;
		this.comment = comment;

		arr.add(this);
	}

	public String strToSave() {
		return String.format("%s;%s;%s;%s;%s", name, definition, status, author, comment);
	}

//	@Override
//	public String toString() {
//		return String.format("Name: %s\nDefinition: %s\nStatus: %s\nAuthor: %s\nComment: %s", name, definition, status,
//				author, comment);
//	}
}
